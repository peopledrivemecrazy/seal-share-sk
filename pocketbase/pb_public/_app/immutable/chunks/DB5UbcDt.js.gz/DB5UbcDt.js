import{o,E as f,w as i,ad as p,V as c,q as d,y as h}from"./BbX6vshq.js";function E(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{E as s};
