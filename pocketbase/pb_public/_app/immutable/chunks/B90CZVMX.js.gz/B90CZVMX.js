import{R as t}from"./CYgJF_JY.js";function n(r,e){throw new t(r,e.toString())}new TextEncoder;export{n as r};
